package com.example.jewel.foodorder.Utils;

import com.example.jewel.foodorder.Model.User;

/**
 * Created by fiber on 17-Dec-17.
 */

public class Utils {

    public static User currentUser;
}
