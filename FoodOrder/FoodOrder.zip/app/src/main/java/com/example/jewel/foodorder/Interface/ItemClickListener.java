package com.example.jewel.foodorder.Interface;

import android.view.View;

/**
 * Created by fiber on 17-Dec-17.
 */

public interface ItemClickListener {

    void onClick(View view, int position, boolean isLongClick);
}

